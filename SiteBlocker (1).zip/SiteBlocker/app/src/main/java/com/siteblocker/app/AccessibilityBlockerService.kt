package com.siteblocker.app

import android.accessibilityservice.AccessibilityService
import android.os.Handler
import android.view.Gravity
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.TextView

class AccessibilityBlockerService : AccessibilityService() {

    override fun onAccessibilityEvent(event: AccessibilityEvent) {
        if (event.eventType != AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED
            && event.eventType != AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED) return

        val url = extractUrlFromEvent(event) ?: return

        if (KeywordManager.shouldBlock(this, url)) {
            showBlockScreen()
        }
    }

    private fun extractUrlFromEvent(event: AccessibilityEvent): String? {
        val source = event.source ?: return null
        val root = source.window?.root ?: return null
        return findUrlInNode(root)
    }

    private fun findUrlInNode(node: AccessibilityNodeInfo?): String? {
        if (node == null) return null
        if (node.viewIdResourceName?.contains("url_bar") == true ||
            node.viewIdResourceName?.contains("location_bar") == true) {
            return node.text?.toString()
        }
        for (i in 0 until node.childCount) {
            val result = findUrlInNode(node.getChild(i))
            if (result != null) return result
        }
        return null
    }

    private fun showBlockScreen() {
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            android.graphics.PixelFormat.OPAQUE
        )
        val view = TextView(this).apply {
            text = "🔒 Site Blocked"
            textSize = 36f
            gravity = Gravity.CENTER
            setBackgroundColor(android.graphics.Color.parseColor("#1A237E"))
            setTextColor(android.graphics.Color.WHITE)
        }
        wm.addView(view, params)
        Handler(mainLooper).postDelayed({
            try { wm.removeView(view) } catch (e: Exception) { /* already removed */ }
            performGlobalAction(GLOBAL_ACTION_BACK)
        }, 1500)
    }

    override fun onInterrupt() {}
}
